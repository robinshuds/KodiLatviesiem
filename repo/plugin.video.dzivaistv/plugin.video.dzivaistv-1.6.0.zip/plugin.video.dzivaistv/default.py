# -*- coding: utf-8 -*-

import sys
import os
import re
import js2py
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
# import urlresolver
import urllib, urllib2, ssl, re
import CommonFunctions
import requests
import json

channelList = {'Latvijas Kanāli': {
									'icon': '%s/Latvia.png',
									'channels':	[{'name': 'LTV1',
												'thumb': '%s/ltv1.png',
												'sources': [{'name':'LTV1 - Tiešraide 1 [COLOR red][Ārzemes Neies][/COLOR]', 'url': 'resolve_ltv1_source1'},
															{'name':'LTV1 - Tiešraide 2 [COLOR red][Ārzemes Neies][/COLOR]', 'url': 'http://dvb.gpsystems.lv:4242/bynumber/1?by_HasBahCa'}]
												},
												{'name': 'LTV7',
												'thumb': '%s/ltv7.png',
												'sources': [{'name': 'LTV7 - Tiešraide 1 [COLOR red][Ārzemes Neies][/COLOR]', 'url': 'resolve_ltv7_source1'},
															{'name': 'LTV7 - Tiešraide 2 [COLOR red][Ārzemes Neies][/COLOR]', 'url': 'http://dvb.gpsystems.lv:4242/bynumber/3'}]
												},
												{'name': 'TV3 Latvija',
												'thumb': '%s/tv3.png',
												'sources': [{'name': 'TV3 Latvija - High', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream2_high.stream/chunklist.m3u8'},
															{'name': 'TV3 Latvija - Medium', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream2_medium.stream/chunklist.m3u8'},
															{'name': 'TV3 Latvija - Low', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream2_low.stream/chunklist.m3u8'}]
												},
												{'name': 'LNT',
												'thumb': '%s/lnt.png',
												'sources': [{'name': 'LNT - High', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream1_high.stream/playlist.m3u8'},
															{'name': 'LNT - Medium', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream1_medium.stream/playlist.m3u8'},
															{'name': 'LNT - Low', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream1_low.stream/playlist.m3u8'}]
												},
												{'name': 'TV6 Latvija',
												'thumb': '%s/tv6.png',
												'sources': [{'name': 'TV6 Latvija - High', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream4_high.stream/playlist.m3u8'},
															{'name': 'TV6 Latvija - Medium', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream4_medium.stream/playlist.m3u8'},
															{'name': 'TV6 Latvija - Low', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream4_low.stream/playlist.m3u8'}]
												},
												{'name': 'Kanāls 2',
												'thumb': '%s/kanals2.png',
												'sources': [{'name': 'Kanāls 2 - High', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream3_high.stream/playlist.m3u8'},
															{'name': 'Kanāls 2 - Medium', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream3_medium.stream/playlist.m3u8'},
															{'name': 'Kanāls 2 - Low', 'url': 'http://wpc.11eb4.teliasoneracdn.net/8011EB4/origin1/tvplay/mtgstream3_low.stream/playlist.m3u8'}]
												},
												{'name': 'PBMK',
												'thumb': '%s/pbmk.png',
												'sources': [{'name': 'Первый Балтийский Музыкальный', 'url': 'https://streamer4.tvdom.tv/PBMK/tracks-v1a1/index.m3u8?token=token1'}]
												},
												{'name': 'Testa Strīmi',
												'thumb': '%s/test.png',
												'sources': [{'name': 'Viasat Sport Baltic', 'url': 'http://cdn.smotrimult.com/hls/oU4Z3FCVitlJ1yRDK2InXQ/1480787415/sportbaltic.m3u8'}]
												}]
								  },
			  'Populārzinātniskie Kanāli': {
									'icon': '%s/science.png',
									'channels':	[{'name': 'Discovery Channel',
												'thumb': '%s/discoverychannel.png',
												'sources': [{'name':'Discovery Channel - [English]', 'url': 'resolve_discoverychannel_source1'},
															{'name':'SeeTV|Discovery Channel - [Russian]', 'url': 'resolve_discoverychannel_rus'}]
												},
												{'name': 'Discovery Science',
												'thumb': '%s/discoveryscience.png',
												'sources': [{'name':'Discovery Science - [English]', 'url': 'resolve_discoverychannelhd_source1'},
															{'name':'SeeTV|Discovery Science - [Russian]', 'url': 'resolve_discoveryscience_rus'}]
												},
												{'name': 'Animal Planet',
												'thumb': '%s/AnimalPlanet.png',
												'sources': [{'name':'Animal Planet- [Russian]', 'url': 'resolve_animalplanet_rus'}]
												},
												{'name': 'NASA TV',
												'thumb': '%s/nasatv.png',
												'sources': [{'name':'NASA TV - [English]', 'url': 'http://nasatv-lh.akamaihd.net/i/NASA_101@319270/master.m3u8'}]
												},												
												{'name': 'Viasat Explorer',
												'thumb': '%s/viasatexplorer.png',
												'sources': [{'name':'tvid.us|Viasat Explorer - [Russian]', 'url': 'http://178.124.183.19/hls/CH_VIASATEXPLORER/variant.m3u8?'},
															{'name':'TIVIX|Viasat Explorer - [Russian]', 'url': 'resolve_viasatexplorer_tivix'}]
												},
												{'name': 'Viasat History',
												'thumb': '%s/viasathistory.png',
												'sources': [{'name':'SeeTV|Viasat History - [Russian]', 'url': 'resolve_viasathistory'},
															{'name':'TIVIX|Viasat History - [Russian]', 'url': 'resolve_viasathistory_tivix'}]
												},
												{'name': 'Viasat Nature',
												'thumb': '%s/viasatnature.png',
												'sources': [{'name':'SeeTV|Viasat Nature - [Russian]', 'url': 'resolve_viasatnature'},
															{'name':'TIVIX|Viasat Nature - [Russian]', 'url': 'resolve_viasatnature_tivix'}]
												},
												{'name': 'National Geographic Channel',
												'thumb': '%s/nationalgeographic.png',
												'sources': [{'name':'SeeTV|National Geographic Channel - [Russian]', 'url': 'resolve_nationalgeographic_rus'}]
												},
												{'name': 'Nat Geo Wild',
												'thumb': '%s/natgeowild.png',
												'sources': [{'name':'SeeTV|Nat Geo Wild - [Russian]', 'url': 'resolve_natgeowild_rus'},
															{'name':'TIVIX|Nat Geo Wild - [Russian]', 'url': 'resolve_natgeowild_tivix'}]
												}]
								  },
			  'русские каналы': {
									'icon': '%s/Russia.png',
									'channels':	[{'name': 'СТБ',
												'thumb': '%s/stb.png',
												'sources': [{'name':'SeeTV|СТБ', 'url': 'resolve_stb'}]
												},
												{'name': 'ТНТ ',
												'thumb': '%s/tnt.png',
												'sources': [{'name':'SeeTV|ТНТ', 'url': 'resolve_tnt'},
															{'name':'TIVIX|ТНТ', 'url': 'resolve_tnt_tivix'}]
												},
												{'name': 'ТНТ4 (Comedy TV)',
												'thumb': '%s/tnt4.png',
												'sources': [{'name':'SeeTV|ТНТ4 (Comedy TV)', 'url': 'resolve_tnt4'},
															{'name':'TIVIX|ТНТ4 (Comedy TV)', 'url': 'resolve_tnt4_tivix'}]
												},												
												{'name': 'Кинохит',
												'thumb': '%s/kinohit.png',
												'sources': [{'name':'SeeTV|Кинохит', 'url': 'resolve_kinohit'},
															{'name':'TIVIX|Кинохит', 'url': 'resolve_kinohit_tivix'}]
												},
												{'name': 'Рен ТВ',
												'thumb': '%s/rentv.png',
												'sources': [{'name':'SeeTV|Рен ТВ', 'url': 'resolve_rentv'},
															{'name':'TIVIX|Рен ТВ', 'url': 'resolve_rentv_tivix'}]
												},
												{'name': 'СТС',
												'thumb': '%s/sts.png',
												'sources': [{'name':'SeeTV|СТС', 'url': 'resolve_sts'},
															{'name':'TIVIX|СТС', 'url': 'resolve_sts_tivix'}]
												},
												{'name': 'Первый канал',
												'thumb': '%s/1kanal.png',
												'sources': [{'name':'SeeTV|Первый канал', 'url': 'resolve_1kanal'},
															{'name':'SeeTV|Первый канал', 'url': 'resolve_1kanal_tivix'}]
												}]
								  },
				'Mūzikas Kanāli': {
									'icon': '%s/music2.png',
									'channels':	[{'name': '1HD Music Television',
												'thumb': '%s/1HD.png',
												'sources': [{'name': '1HD Music Television', 'url': 'http://80.250.191.10:1935/live/hlsstream343/playlist.m3u8'}]
												},
												{'name': '365 Music TV',
												'thumb': '%s/365music.png',
												'sources': [{'name': '365 Music TV', 'url': 'https://str4.365music.ru/365music_hls/tracks-v1a1/index.m3u8'}]
												},
												{'name': 'MTV Hits',
												'thumb': '%s/mtvhits.png',
												'sources': [{'name': 'TIVIX|MTV Hits', 'url': 'resolve_mtvhits_tivix'}]
												},
												{'name': 'MTV Dance',
												'thumb': '%s/mtvdance.png',
												'sources': [{'name': 'TIVIX|MTV Dance', 'url': 'resolve_mtvdance_tivix'}]
												},
												{'name': 'Music Box UA',
												'thumb': '%s/musicboxua.png',
												'sources': [{'name': 'TIVIX|Music Box UA', 'url': 'resolve_musicboxua_tivix'}]
												},
												{'name': 'VH1',
												'thumb': '%s/vh1.png',
												'sources': [{'name': 'TIVIX|VH1', 'url': 'resolve_vh1_tivix'}]
												},
												{'name': 'VH1 Classic',
												'thumb': '%s/vh1classic.png',
												'sources': [{'name': 'TIVIX|VH1 Classic', 'url': 'resolve_vh1classic_tivix'}]
												},
												{'name': 'M1',
												'thumb': '%s/m1.png',
												'sources': [{'name': 'TIVIX|M1', 'url': 'resolve_m1_tivix'}]
												}]
								  }
			  }
							  
mysettings = xbmcaddon.Addon(id = 'plugin.video.dzivaistv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
getSetting = xbmcaddon.Addon().getSetting
iconpath = xbmc.translatePath(os.path.join(home, 'resources/icons/'))

skin_used = xbmc.getSkinDir()


def showkeyboard(txtMessage="",txtHeader="",passwordField=False):
    if txtMessage=='None': txtMessage=''
    keyboard = xbmc.Keyboard(txtMessage, txtHeader, passwordField)#("text to show","header text", True="password field"/False="show text")
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    else:
        return False # return ''
		
		
def postHTML(url, post_fields):

	if sys.hexversion >= 0x02070BF0:
		r = requests.post(url, data=post_fields)
		print(r.status_code, r.reason)
		html = r.text.encode('utf-8')
	else:
		print "Crap we have the old version"
	
		
		# http://dev.morf.lv/mirror.php?url=https://cinemalive.tv/scripts/search.php&post=
		postParam = ""
		for key, value in post_fields.iteritems():
			postParam+=key+":"+value
		
		r = requests.get("http://dev.morf.lv/mirror.php?url="+url+"&post="+postParam)
		print(r.status_code, r.reason)
		html = r.text.encode('utf-8')
		
	
	#Let's just itterate through stupid encoding/decodings
	try:
		html = html.decode('utf-8').encode('utf-8')
	except:		
		html = html.decode('latin-1').encode('utf-8')
		
	# test = html.encode('latin1').decode('utf8')
	# print test
	
	return html
	
def getHTML(url, data = False):	   
	print "Downloading URL... " + url
	
	hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
		'Accept-Encoding': 'none',
		'Accept-Language': 'pl-PL,pl;q=0.8',
		'Connection': 'keep-alive'}
		

	if sys.hexversion >= 0x02070BF0:
		print "Cool, we have TLSv1 Support"
		
		context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
		context.verify_mode = ssl.CERT_NONE
		context.check_hostname = False
	
		req = urllib2.Request(url, headers=hdr)

		try:
			page = urllib2.urlopen(req,context=context)
		except urllib2.HTTPError, e:
			print "ERROR while downloading: " + e.fp.read()
			return

		html = page.read()
	else:
		print "Crap we have the old version"
		
		req = urllib2.Request("http://dev.morf.lv/mirror.php?url="+url, headers=hdr)
		
		try:
			page = urllib2.urlopen(req)
		except urllib2.HTTPError, e:
			print e.fp.read()
			return

		html = page.read()
		
	print "Length of the string: ", len(html)
	
	#Let's just itterate through stupid encoding/decodings
	try:
		html = html.decode('utf-8').encode('utf-8')
	except:		
		html = html.decode('latin-1').encode('utf-8')
	
	print "URL Downloaded"
	return html
	
	
def resolve_ltv1_source1():
	html = getHTML('http://embed.ls.lv/ltv1g/index.php?utm_medium=ltv1')
	searchObj = re.search('file: ".*"', html)
	if searchObj:
		resolvedUrl = searchObj.group().replace('file: "', '')
		resolvedUrl = resolvedUrl[:-1]
		return resolvedUrl
	else:
	   return False
	
def resolve_ltv7_source1():
	html = getHTML('http://embed.ls.lv/ltv2g/index.php?utm_medium=ltv2')
	searchObj = re.search('file: ".*"', html)
	if searchObj:
		resolvedUrl = searchObj.group().replace('file: "', '')
		resolvedUrl = resolvedUrl[:-1]
		return resolvedUrl
	else:
	   return False
	  

def resolve_discoverychannelhd_source1():
	hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
		'Accept-Encoding': 'none',
		'Accept-Language': 'pl-PL,pl;q=0.8',
		'Connection': 'keep-alive'}
		
	req = urllib2.Request('http://www.tikilive.com/embed?scheme=embedChannel&channelId=41598&autoplay=yes&showChat=no', headers=hdr)

	try:
		page = urllib2.urlopen(req)
	except urllib2.HTTPError, e:
		print "ERROR while downloading: " + e.fp.read()
		return

	html = page.read()
	# html = getHTML()
	print html
	#resolve channelId
	searchObj = re.search("hlsCdnMoChannelId: '\d*'", html)
	if searchObj:
		channelId = searchObj.group().replace("hlsCdnMoChannelId: '", '')
		channelId = channelId[:-1]		
	else:
	   return False
	   
	#resolve start time
	searchObj = re.search("hlsCdnMoStime: '\d*'", html)
	if searchObj:
		hlsCdnMoStime = searchObj.group().replace("hlsCdnMoStime: '", '')
		hlsCdnMoStime = hlsCdnMoStime[:-1]		
	else:
	   return False
	   
	   
	#resolve end time
	searchObj = re.search("hlsCdnMoEtime: '\d*'", html)
	if searchObj:
		hlsCdnMoEtime = searchObj.group().replace("hlsCdnMoEtime: '", '')
		hlsCdnMoEtime = hlsCdnMoEtime[:-1]		
	else:
	   return False
	   
	#resolve token id
	searchObj = re.search("hlsCdnMoToken: '[\d\w]*'", html)
	if searchObj:
		hlsCdnMoToken = searchObj.group().replace("hlsCdnMoToken: '", '')
		hlsCdnMoToken = hlsCdnMoToken[:-1]		
	else:
	   return False
   
	return "http://tv-tikilive-live.hls.adaptive.level3.net/show_demotiki/405/amlst:mainstream/playlist.m3u8?op_id=19&userId=0&channelId="+channelId+"&stime="+hlsCdnMoStime+"&etime="+hlsCdnMoEtime+"&token="+hlsCdnMoToken
	
def resolve_discoverychannel_source1():
	hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
		'Accept-Encoding': 'none',
		'Accept-Language': 'pl-PL,pl;q=0.8',
		'Connection': 'keep-alive'}
		
	req = urllib2.Request('http://www.tikilive.com/embed?scheme=embedChannel&channelId=40686&autoplay=yes&showChat=no', headers=hdr)

	try:
		page = urllib2.urlopen(req)
	except urllib2.HTTPError, e:
		print "ERROR while downloading: " + e.fp.read()
		return

	html = page.read()
	# html = getHTML()
	print html
	#resolve channelId
	searchObj = re.search("hlsCdnMoChannelId: '\d*'", html)
	if searchObj:
		channelId = searchObj.group().replace("hlsCdnMoChannelId: '", '')
		channelId = channelId[:-1]		
	else:
	   return False
	   
	#resolve start time
	searchObj = re.search("hlsCdnMoStime: '\d*'", html)
	if searchObj:
		hlsCdnMoStime = searchObj.group().replace("hlsCdnMoStime: '", '')
		hlsCdnMoStime = hlsCdnMoStime[:-1]		
	else:
	   return False
	   
	   
	#resolve end time
	searchObj = re.search("hlsCdnMoEtime: '\d*'", html)
	if searchObj:
		hlsCdnMoEtime = searchObj.group().replace("hlsCdnMoEtime: '", '')
		hlsCdnMoEtime = hlsCdnMoEtime[:-1]		
	else:
	   return False
	   
	#resolve token id
	searchObj = re.search("hlsCdnMoToken: '[\d\w]*'", html)
	if searchObj:
		hlsCdnMoToken = searchObj.group().replace("hlsCdnMoToken: '", '')
		hlsCdnMoToken = hlsCdnMoToken[:-1]		
	else:
	   return False
   
	return "http://tv-tikilive-live.hls.adaptive.level3.net/show_demotiki/11/amlst:mainstream/playlist.m3u8?op_id=19&userId=0&channelId="+channelId+"&stime="+hlsCdnMoStime+"&etime="+hlsCdnMoEtime+"&token="+hlsCdnMoToken
	
def resolve_seetv_stream(url):

	session = requests.Session()
	session.cookies.get_dict()
	response = session.get(url)
	html = response.content
	cookies = session.cookies.get_dict()
	print cookies
	# html = getHTML(url)
	
	searchObj = re.search('var linkTv = \d*;', html)
	if searchObj:
		resolvedLinkTv = searchObj.group().replace('var linkTv = ', '')
		resolvedLinkTv = resolvedLinkTv[:-1]
	else:
	   return False

	user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36'
	headers = { 
			'User-Agent' : user_agent,
			'Accept' : 'application/json, text/javascript, */*; q=0.01',
			'Accept-Language' : 'en-US,en;q=0.8,lv;q=0.6,en-GB;q=0.4',
			'Cache-Control' : 'no-cache',
			'Connection' : 'keep-alive',
			# 'Cookie' : '__cfduid=d1c6864852f2a1d64b53f2a0d92e7a6ed1481207982; uppodhtml5_volume=0.8; _ga=GA1.2.1188885436.1481207985; seetv_session_new=f63d8254c650c97898efa5a37f507cc96986279b',
			'Cookie' : '__cfduid='+cookies['__cfduid']+'; seetv_session_new='+cookies['seetv_session_new'],
			'Host' : 'seetv.tv',
			'Pragma' : 'no-cache',
			'Referer' : url,
			'X-Requested-With' : 'XMLHttpRequest'
		}
	req = urllib2.Request('http://seetv.tv/get/player/'+str(resolvedLinkTv), None, headers)
	response = urllib2.urlopen(req)

	result = json.loads(response.read())

	if result['status'] == True:
		# file = result['file'].replace("%3F", "?")
		file = result['file'].replace("%3F", "?")+"|Cookie="+urllib.quote_plus( headers['Cookie'] )+"&HttpProxy="+urllib.quote_plus("http://stream3.seetv.tv:8081")+"&Referer="+urllib.quote_plus(url)
		print (file)
		return file
	else:
		print False

	response.close()

def resolve_discoverychannel_rus():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/discovery-channel-tv' )
	
def resolve_discoveryscience_rus():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/discovery-science' )
	
def resolve_nationalgeographic_rus():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/national-geographic-channel' )
	
def resolve_natgeowild_rus():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/natgeowild' )

def resolve_stb():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/stb-ch-ua' )
	
def resolve_tnt():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/tnt-tv-202' )
	
def resolve_tnt4():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/tnt-comedy' )
	
def resolve_kinohit():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/kinohit' )
	
def resolve_viasathistory():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/viasathistory' )
	
def resolve_viasatnature():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/viasatnature' )
	
def resolve_animalplanet_rus():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/animalplanet' )
	
def resolve_rentv():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/peh-tb' )
	
def resolve_sts():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/ctc' )
	
def resolve_1kanal():
	return resolve_seetv_stream( 'http://seetv.tv/vse-tv-online/perviy-kanal' )
	

def getURLFromObfJs(js):
	progress_dialog = xbmcgui.DialogProgress()
	progress_dialog.create("Dekodējam strīmu")
	js = js.replace(";eval", "fnRes=")
	print "return" in js
	#evalFn = js.split("'));")
	#print len(evalFn)
	#print evalFn

	count = 0
	maxTries = 4
	while "var value={" not in js or count == maxTries:
		progress = int(float((float(count)/maxTries)*100))
		print "Evaluating: " + str(count)
		progress_dialog.update( progress , "Lūdzu uzgaidi...", "Rūķīši cenšas dekodēt TIVIX strīmu", "Atlicis: " + str(maxTries - count) )
		if (progress_dialog.iscanceled()): return
		js = str(js2py.eval_js(js))
		js = js.replace(";eval", "fnRes=")
		count += 1

	#print js

	searchObj = re.search("'value':'[\'\w\d:\/.?=]*}", js)
	if searchObj:
		resolvedUrl = searchObj.group().replace("'value':'", "")
		resolvedUrl = resolvedUrl[:-2]
		return resolvedUrl
	else:
		return False
		
def resolve_tivix_stream(url):

	session = requests.Session()
	session.cookies.get_dict()
	response = session.get(url)
	html = response.content
	cookies = session.cookies.get_dict()
	print cookies
	# html = getHTML(url)
	
	searchObj = re.search("<div id=\"advm_video\"><\/div>[ \\n\\r]*<script>[\\w\\d;\\n\\r\\t (),{}=\\[\\]<>\\.\\+\\'\\-\\%]*<\\/script>", html)
	if searchObj:
		resolvedJS = searchObj.group().replace("</script>","").split("<script>")[1].strip()
		# print resolvedLinkTv
		# resolvedLinkTv = resolvedLinkTv[:-1]
	else:
	   return False
	   
	header_m3u8 = {
			'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36',
			'Accept' : '*/*',
			'Accept-Encoding' : 'gzip, deflate, sdch',
			'X-Requested-With' : 'ShockwaveFlash/24.0.0.175',
			'Cookie' : 'PHPSESSID='+cookies['PHPSESSID'],
			# 'Host' : 'stream3.seetv.tv:8081',
			# 'HttpProxy' : 'http://stream3.seetv.tv:8081',
			'Pragma' : 'no-cache',
			'Cache-Control' : 'no-cache',
			'Connection' : 'keep-alive',
			'Referer' : url
	}
	
	resolvedStreamURL = getURLFromObfJs(resolvedJS)+"|"+urllib.urlencode(header_m3u8)
	print "TIVIX stream URL: " + resolvedStreamURL
	return 	resolvedStreamURL
	
def resolve_natgeowild_tivix():
	return resolve_tivix_stream("http://tivix.co/347-nat-geo-wild.html")
	
def resolve_viasatnature_tivix():
	return resolve_tivix_stream("http://tivix.co/180-viasat-nature.html")
	
def resolve_viasathistory_tivix():
	return resolve_tivix_stream("http://tivix.co/116-viasat-history.html")
	
def resolve_viasatexplorer_tivix():
	return resolve_tivix_stream("http://tivix.co/119-viasat-explorer.html")

def resolve_sts_tivix():
	return resolve_tivix_stream("http://tivix.co/11-sts.html")
	
def resolve_tnt_tivix():
	return resolve_tivix_stream("http://tivix.co/10-tnt.html")
	
def resolve_tnt4_tivix():
	return resolve_tivix_stream("http://tivix.co/29-kamedi-tv.html")
	
def resolve_kinohit_tivix():
	return resolve_tivix_stream("http://tivix.co/328-kinohit.html")
	
def resolve_rentv_tivix():
	return resolve_tivix_stream("http://tivix.co/8-ren-tv.html")
	
def resolve_1kanal_tivix():
	return resolve_tivix_stream("http://tivix.co/336-pervyy-kanal.html")
	
def resolve_mtvhits_tivix():
	return resolve_tivix_stream("http://tivix.co/159-mtv-hits.html")
	
def resolve_mtvdance_tivix():
	return resolve_tivix_stream("http://tivix.co/161-mtv-dance.html")
	
def resolve_musicboxua_tivix():
	return resolve_tivix_stream("http://tivix.co/158-music-box-ua.html")
	
def resolve_vh1_tivix():
	return resolve_tivix_stream("http://tivix.co/265-vh1-europe.html")
	
def resolve_vh1classic_tivix():
	return resolve_tivix_stream("http://tivix.co/264-vh1-classik.html")
	
def resolve_m1_tivix():
	return resolve_tivix_stream("http://tivix.co/348-m1.html")

def get_categories():
         """
         Get's the list of channel categories: Latvian, Russian, Sport etc.
         """
         return channelList.keys()
		 
def get_sources(category, channel):
	channels = channelList[category]['channels']
	
	for ch in channels:
		if ch['name'] == channel:
			return ch['sources']
			
	return
	
def get_channel_icon(category, channel):
	channels = channelList[category]['channels']
	
	for ch in channels:
		if ch['name'] == channel:
			return ch['thumb']
			
	return
	
def isURL(url):
	try:
		f = urllib2.urlopen(url)
		return True
	except ValueError:  # invalid URL
		return False
	except:
		return True
		 
def HomeNavigation():
	categories = get_categories()
	for category in categories:
		addDir(category, category, 'state_channels', channelList[category]['icon']% iconpath)

	
def Channels(category):
	channels = channelList[category]['channels']
	for channel in channels:
		addDir(channel['name'], category+":"+channel['name'], 'state_sources', channel['thumb']% iconpath)
		
def Sources(url):
	splitParam = url.split(":")
	
	category = splitParam[0]
	channel = splitParam[1]
	print category, channel
	sources = get_sources(category, channel)
	
	for i in range(0, len(sources)):
		print isURL(sources[i]['url']), sources[i]
		if isURL(sources[i]['url']) == False:
			resolvedUrl = globals()[sources[i]['url']]()
			if resolvedUrl != False:
				addLink(sources[i]['name'], resolvedUrl, get_channel_icon(category, channel)% iconpath)
		else:
			addLink(sources[i]['name'], sources[i]['url'], get_channel_icon(category, channel)% iconpath)
			
	
	

def addDir(title, url, mode, picture, page=None):
    sys_url = sys.argv[0] + '?title=' + urllib.quote_plus(title) + '&url=' + urllib.quote_plus(url) + '&mode=' + urllib.quote_plus(str(mode))
    if  picture == None:
        item = xbmcgui.ListItem(title, iconImage='DefaultFolder.png', thumbnailImage='')
    else:
        item = xbmcgui.ListItem(title, iconImage='DefaultFolder.png' , thumbnailImage=picture)    
        sys_url += '&picture=' + urllib.quote_plus(str(picture))
    if page != None:
        sys_url += '&page=' + urllib.quote_plus(str(page))
    item.setInfo(type='Video', infoLabels={'Title': title})

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys_url, listitem=item, isFolder=True)
	
def addLink(title, url, picture):
    if  picture == None:
        item = xbmcgui.ListItem(title, iconImage='DefaultVideo.png', thumbnailImage='')
    else:
		item = xbmcgui.ListItem(title, iconImage='DefaultVideo.png', thumbnailImage=picture)
    item.setInfo( type='Video', infoLabels={'Title': title} )	
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=item)
	
def play_stream(url):
	media_url = url
	print "MEDIA URL " + media_url
	item = xbmcgui.ListItem('TV3 Latvia', path = media_url)
	# xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	# xbmcplugin.setResolvedUrl( handle=int( sys.argv[1]), succeeded=False, listitem=item )
	listItem = xbmcgui.ListItem("Tesfilm", path=media_url)
	xbmc.Player().play(item=media_url, listitem=listItem)
	return
	
def SetThumbnailView():
	if skin_used == 'skin.confluence':
		xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
		
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
                            
    return param

common = CommonFunctions
common.plugin = "Filmas-Latviski-0.0.1"

params = get_params()
url = None
title = None
mode = None
picture = None
page = 1

try:
    title = urllib.unquote_plus(params['title'])
except:
    pass
try:
    url = urllib.unquote_plus(params['url'])
except:
    pass
try:
    mode = urllib.unquote_plus(params['mode'])
except:
    pass
try:
    picture = urllib.unquote_plus(params['picture'])
except:
    pass
try:
    page = int(params['page'])
except:
    pass

if mode == None:
	HomeNavigation()
	SetThumbnailView()
elif mode == 'state_channels':
	Channels(url)
	SetThumbnailView()
elif mode =='state_sources':
	Sources(url)

		

# print(requests.get("https://cinemalive.tv/filmaslatviski", verify=False))

	
xbmcplugin.endOfDirectory(int(sys.argv[1]))


# content = getHTML("https://cinemalive.tv/filmaslatviski");
# print content
	




# addon_handle = int(sys.argv[1])

# xbmcplugin.setContent(addon_handle, 'movies')

# url = urlresolver.resolve('https://openload.co/embed/eCLBpX3iByw/') 

# li = xbmcgui.ListItem('Sapinusies', iconImage='DefaultVideo.png')
# xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

# xbmcplugin.endOfDirectory(addon_handle)


